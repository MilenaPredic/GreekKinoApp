//
//  GrckiKinoAppApp.swift
//  GrckiKinoApp
//
//  Created by Milena Predic on 12.2.24..
//

import SwiftUI

@main
struct GrckiKinoAppApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
